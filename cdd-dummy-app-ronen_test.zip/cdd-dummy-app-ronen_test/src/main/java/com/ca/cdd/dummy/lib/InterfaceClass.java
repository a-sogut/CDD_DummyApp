package com.ca.cdd.dummy.lib;

public interface InterfaceClass {


    Integer useAbstractInInterface();

    String interfaceStingMethod();
}
