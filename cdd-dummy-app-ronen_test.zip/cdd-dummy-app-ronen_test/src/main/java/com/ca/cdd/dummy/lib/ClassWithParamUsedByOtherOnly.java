package com.ca.cdd.dummy.lib;

public class ClassWithParamUsedByOtherOnly extends Library {

    private static String NAME = "ClassWithParamUsedByOtherOnly";

    public String toUseFromExtendClass = "Parameter Called from extend Class";


    @Override
    public String getName() {
        return NAME;
    }
}
