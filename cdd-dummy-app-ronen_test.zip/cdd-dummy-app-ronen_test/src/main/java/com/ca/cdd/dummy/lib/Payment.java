package com.ca.cdd.dummy.lib;

public class Payment extends Library {
    private static String NAME = "Comics1";
    @Override
    public String getName() {
        return NAME;
    }
    
}

