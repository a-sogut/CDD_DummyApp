package com.ca.cdd.dummy.lib;

public class Thread5UnkerPkgLib implements Runnable {
    @Override
    public void run() {
        System.out.println("I am Thread 5");
    }

    public static String getName() {return "Thread5UnkerPkgLib";
    }
}
