package com.ca.cdd.dummy.lib;

public class FailTestSuite extends Library {
    private static String NAME = "FailScenario";



    @Override
    public String getName() {
        return NAME;
    }


    
}
