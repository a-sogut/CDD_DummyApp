package com.ca.cdd.dummy.lib;

public class ExactSciencesLibrary extends Library {
    private static String NAME = "ExactSciences1";

    @Override
    public String getName() {
        return NAME;
    }
}
