# cdd-dummy-app

An application to be used for testing other apps.  
Initially used to test tar-agent.


